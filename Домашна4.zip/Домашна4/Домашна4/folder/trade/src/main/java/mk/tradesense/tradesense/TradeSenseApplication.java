package mk.tradesense.tradesense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TradeSenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(TradeSenseApplication.class, args);
	}

}
