package mk.tradesense.gatewayservice.filters;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

@Component
public class JwtAuthenticationFilter extends AbstractGatewayFilterFactory<JwtAuthenticationFilter.Config> {

    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Value("${auth-service.url}")
    private String authServiceUrl;

    private final WebClient.Builder webClientBuilder;

    public JwtAuthenticationFilter(WebClient.Builder webClientBuilder) {
        super(Config.class);
        this.webClientBuilder = webClientBuilder;
    }

    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            String token = extractToken(exchange.getRequest().getHeaders());

            if (token == null) {
                logger.warn("No valid authorization token found for request: {}", exchange.getRequest().getURI());
                return setUnauthorizedResponse(exchange, config);
            }

            logger.info("Validating token for request: {}", exchange.getRequest().getURI());

            return validateToken(token)
                    .flatMap(userDetails -> {
                        logger.info("Token validated. User: {}", userDetails.get("username"));
                        injectUserDetails(exchange, userDetails);
                        return chain.filter(exchange);
                    })
                    .onErrorResume(error -> {
                        logger.error("Token validation failed: {}", error.getMessage());
                        return setUnauthorizedResponse(exchange, config);
                    });
        };
    }

    private String extractToken(HttpHeaders headers) {
        String token = headers.getFirst(HttpHeaders.AUTHORIZATION);
        return (token != null && token.startsWith("Bearer ")) ? token : null;
    }

    private Mono<Map> validateToken(String token) {
        return webClientBuilder.build()
                .post()
                .uri(authServiceUrl)
                .header(HttpHeaders.AUTHORIZATION, token)
                .retrieve()
                .onStatus(
                        HttpStatus::isError,
                        response -> response.bodyToMono(String.class)
                                .flatMap(errorBody -> Mono.error(new RuntimeException("Invalid Token: " + errorBody)))
                )
                .bodyToMono(Map.class);
    }

    private void injectUserDetails(org.springframework.web.server.ServerWebExchange exchange, Map<String, Object> userDetails) {
        exchange.getRequest().mutate()
                .header("X-Username", userDetails.get("username").toString())
                .build();
    }

    private Mono<Void> setUnauthorizedResponse(org.springframework.web.server.ServerWebExchange exchange, Config config) {
        exchange.getResponse().setStatusCode(config.getUnauthorizedStatus());
        return exchange.getResponse().setComplete();
    }

    public static class Config {
        private HttpStatus unauthorizedStatus = HttpStatus.UNAUTHORIZED;

        public HttpStatus getUnauthorizedStatus() {
            return unauthorizedStatus;
        }

        public Config setUnauthorizedStatus(HttpStatus unauthorizedStatus) {
            this.unauthorizedStatus = unauthorizedStatus;
            return this;
        }
    }
}
