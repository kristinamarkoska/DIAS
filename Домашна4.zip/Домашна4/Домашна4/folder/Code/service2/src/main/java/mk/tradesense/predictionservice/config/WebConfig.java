package mk.tradesense.predictionservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig {

    private static final String ALLOWED_ORIGIN = "http://localhost:3000";
    private static final String[] ALLOWED_METHODS = {"GET", "POST", "PUT", "DELETE", "OPTIONS"};

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**")
                        .allowedOrigins(ALLOWED_ORIGIN)
                        .allowedMethods(ALLOWED_METHODS)
                        .allowedHeaders("*")
                        .allowCredentials(true);
                registry.addMapping("/auth/**")
                        .allowedOrigins(ALLOWED_ORIGIN)
                        .allowedMethods(ALLOWED_METHODS)
                        .allowedHeaders("*")
                        .allowCredentials(true);
            }
        };
    }
}
