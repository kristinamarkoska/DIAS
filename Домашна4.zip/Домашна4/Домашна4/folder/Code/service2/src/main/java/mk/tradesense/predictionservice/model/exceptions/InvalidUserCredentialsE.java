package mk.tradesense.predictionservice.model.exceptions;

public class InvalidUserCredentialsE extends RuntimeException {
    public InvalidUserCredentialsE() {
        super("Invalid user credentials");
    }
}
