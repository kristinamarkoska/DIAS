package mk.tradesense.predictionservice.model.exceptions;

public class InvalidArgumentsE extends RuntimeException {
    public InvalidArgumentsE() {
        super("Invalid arguments");
    }
}
