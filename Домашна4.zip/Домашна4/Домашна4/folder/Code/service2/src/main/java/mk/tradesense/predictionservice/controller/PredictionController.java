package mk.tradesense.predictionservice.controller;

import mk.tradesense.predictionservice.model.Sentiment;
import mk.tradesense.predictionservice.model.Signal;
import mk.tradesense.predictionservice.repository.SentimentRepository;
import mk.tradesense.predictionservice.repository.SignalRepository;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

@RestController
@RequestMapping("/api/predictions")
public class PredictionController {

    private final SignalRepository signalRepository;
    private final SentimentRepository sentimentRepository;
    private final String pythonPath;

    public PredictionController(SignalRepository signalRepository, SentimentRepository sentimentRepository) {
        this.signalRepository = signalRepository;
        this.sentimentRepository = sentimentRepository;
        this.pythonPath = System.getenv("PYTHON_PATH");

        if (pythonPath == null) {
            throw new IllegalStateException("PYTHON_PATH environment variable is not set");
        }
    }

    @PostMapping("/technical-analysis")
    public String runTechnicalAnalysis(@RequestParam String stockCode) {
        try {
            Process process = new ProcessBuilder(pythonPath, "src/main/java/mk/tradesense/predictionservice/scripts/technical.py", stockCode).start();
            String output = getProcessOutput(process);
            process.waitFor();

            return "Technical analysis completed: " + output;

        } catch (Exception e) {
            e.printStackTrace();
            return "Error executing technical analysis: " + e.getMessage();
        }
    }

    @GetMapping("/signals")
    public List<Signal> getSignals(@RequestParam String stockCode) {
        return signalRepository.findSignalsByStockCode(stockCode);
    }

    @GetMapping("/sentiments/{stockCode}")
    public Sentiment getSentiment(@PathVariable String stockCode) {
        return sentimentRepository.findByStockCode(stockCode);
    }

    private String getProcessOutput(Process process) throws Exception {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            StringBuilder output = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            return output.toString();
        }
    }
}
