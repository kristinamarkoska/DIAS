package mk.tradesense.predictionservice.model.exceptions;

public class Pass extends RuntimeException {
    public Pass() {
        super("Passwords do not match");
    }
}
