package mk.tradesense.predictionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PredictionServiceAppTests {

	@Test
	void contextLoads() {
	}

}
