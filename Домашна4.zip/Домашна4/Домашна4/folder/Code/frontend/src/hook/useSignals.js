import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

const useSignals = (stockCode) => {
    const [state, setState] = useState({
        signals: [],
        loading: true,
        error: null,
    });

    const { authToken } = useAuth();

    useEffect(() => {
        if (!stockCode) return;

        const fetchSignals = async () => {
            setState({ signals: [], loading: true, error: null });
            try {
                const { data } = await axios.get(`http://localhost:9090/api/predictions/signals`, {
                    params: { stockCode },
                    headers: {
                        Authorization: `Bearer ${authToken}`, // Include JWT token
                    },
                });
                setState({ signals: data, loading: false, error: null });
            } catch (err) {
                setState({ signals: [], loading: false, error: err.message || "Failed to fetch signals." });
            }
        };

        fetchSignals();
    }, [stockCode, authToken]);

    return state;
};

export default useSignals;
