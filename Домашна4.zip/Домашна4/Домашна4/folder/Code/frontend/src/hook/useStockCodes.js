import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

export default function useStockCodes() {
    const [state, setState] = useState({
        stockCodes: [],
        loading: true,
        error: null,
    });

    const { authToken } = useAuth();

    useEffect(() => {
        const controller = new AbortController();
        const fetchStockCodes = async () => {
            setState({ stockCodes: [], loading: true, error: null });
            try {
                const { data } = await axios.get('http://localhost:9090/api/stock-items/codes', {
                    headers: {
                        Authorization: `Bearer ${authToken}`, // Add the JWT token
                    },
                    signal: controller.signal,
                });
                setState({ stockCodes: data, loading: false, error: null });
            } catch (error) {
                if (controller.signal.aborted) return;
                setState({
                    stockCodes: [],
                    loading: false,
                    error: error.message || "Failed to fetch stock codes.",
                });
            }
        };

        fetchStockCodes();

        return () => controller.abort();
    }, [authToken]);

    return state;
}
