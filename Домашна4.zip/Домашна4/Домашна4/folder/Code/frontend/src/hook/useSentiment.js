import { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

const useSentiment = (stockCode) => {
    const [state, setState] = useState({
        sentiment: null,
        loading: true,
        error: null,
    });

    const { authToken } = useAuth();

    useEffect(() => {
        if (!stockCode) return;

        const fetchSentiment = async () => {
            setState({ sentiment: null, loading: true, error: null });
            try {
                const { data } = await axios.get(`http://localhost:9090/api/predictions/sentiments/${stockCode}`, {
                    headers: {
                        Authorization: `Bearer ${authToken}`,
                    },
                });
                setState({ sentiment: data, loading: false, error: null });
            } catch (err) {
                setState({ sentiment: null, loading: false, error: err.message || "Failed to fetch sentiment." });
            }
        };

        fetchSentiment();
    }, [stockCode, authToken]);

    return state;
};

export default useSentiment;
