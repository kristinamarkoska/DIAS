import React, { createContext, useContext, useState, useEffect } from 'react';

// Create Auth Context
const AuthContext = createContext();

// Provide Auth Context to the App
export const AuthProvider = ({ children }) => {
    const [authToken, setAuthToken] = useState(null);
    const [username, setUsername] = useState(null);

    // Initialize state from localStorage on mount
    useEffect(() => {
        setAuthToken(localStorage.getItem('authToken'));
        setUsername(localStorage.getItem('username'));
    }, []);

    const login = (token, username) => {
        setAuthToken(token);
        setUsername(username);
        localStorage.setItem('authToken', token);
        localStorage.setItem('username', username);
    };

    const logout = () => {
        setAuthToken(null);
        setUsername(null);
        localStorage.removeItem('authToken');
        localStorage.removeItem('username');
    };

    const isAuthenticated = () => Boolean(authToken);

    return (
        <AuthContext.Provider value={{ authToken, username, login, logout, isAuthenticated }}>
            {children}
        </AuthContext.Provider>
    );
};

// Custom Hook to Use Auth Context
export const useAuth = () => useContext(AuthContext);
