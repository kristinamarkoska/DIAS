package mk.tradesense.authservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Test class for ensuring the Spring Boot application context loads correctly.
 */
@SpringBootTest
public class AuthServiceApplicationTests {

    /**
     * Test to check if the application context loads successfully.
     */
    @Test
    void contextLoads() {
        // Test passes if the application context loads without issues
    }
}
