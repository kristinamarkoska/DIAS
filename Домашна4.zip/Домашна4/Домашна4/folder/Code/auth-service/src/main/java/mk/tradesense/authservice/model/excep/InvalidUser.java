package mk.tradesense.authservice.model.exceptions;

/**
 * Custom exception to indicate invalid user credentials.
 */
public class InvalidUser extends RuntimeException {

    /**
     * Default constructor with a predefined error message.
     */
    public InvalidUser() {
        super("Invalid user credentials provided");
    }

    /**
     * Constructor allowing a custom error message.
     *
     * @param message the custom error message
     */
    public InvalidUserCredentialsException(String message) {
        super(message);
    }
}
