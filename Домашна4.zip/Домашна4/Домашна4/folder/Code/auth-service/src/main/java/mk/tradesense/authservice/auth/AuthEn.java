package mk.tradesense.authservice.jwt;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Custom entry point for handling authentication errors and sending JSON response.
 */
@Component
public class AuthEn implements AuthenticationEntryPoint {

    /**
     * Handles unauthorized access attempts by returning a JSON response with details.
     *
     * @param request       the HttpServletRequest object
     * @param response      the HttpServletResponse object
     * @param authException the exception that triggered this entry point
     * @throws IOException      if an I/O error occurs during response writing
     * @throws ServletException if the request cannot be processed
     */
    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
            throws IOException, ServletException {

        // Set response content type and status
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);

        // Create response body with error details
        Map<String, Object> responseBody = createErrorResponse(authException, request);

        // Convert response body to JSON and write to the response output stream
        writeResponse(response, responseBody);
    }

    /**
     * Creates a map containing the error details for unauthorized access.
     *
     * @param authException the authentication exception
     * @param request       the HttpServletRequest object
     * @return a map containing the error details
     */
    private Map<String, Object> createErrorResponse(AuthenticationException authException, HttpServletRequest request) {
        Map<String, Object> body = new HashMap<>();
        body.put("status", HttpServletResponse.SC_UNAUTHORIZED);
        body.put("error", "Unauthorized");
        body.put("message", authException.getMessage());
        body.put("path", request.getServletPath());
        return body;
    }

    /**
     * Writes the response body as JSON to the HttpServletResponse output stream.
     *
     * @param response the HttpServletResponse object
     * @param body     the response body map
     * @throws IOException if an I/O error occurs during writing the response
     */
    private void writeResponse(HttpServletResponse response, Map<String, Object> body) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.writeValue(response.getOutputStream(), body);
    }
}
