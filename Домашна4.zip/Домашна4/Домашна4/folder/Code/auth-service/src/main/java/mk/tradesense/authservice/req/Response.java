package mk.tradesense.authservice.dto;

import lombok.Getter;
import lombok.Setter;
import mk.tradesense.authservice.model.enumerations.Role;

@Getter
@Setter
public class LoginResponse {
    private String jwtToken;
    private String username;
    private Role role;

    // Constructor
    public LoginResponse(String jwtToken, String username, Role role) {
        this.jwtToken = jwtToken;
        this.username = username;
        this.role = role;
    }

    // Custom toString method for better readability
    @Override
    public String toString() {
        return "LoginResponse{" +
                "jwtToken='[PROTECTED]', " + // Masked token for security
                "username='" + username + '\'' +
                ", role=" + role +
                '}';
    }
}
