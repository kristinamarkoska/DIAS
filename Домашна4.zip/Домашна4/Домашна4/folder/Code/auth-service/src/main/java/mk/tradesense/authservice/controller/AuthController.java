package mk.tradesense.authservice.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.tradesense.authservice.dto.LoginRequest;
import mk.tradesense.authservice.dto.LoginResponse;
import mk.tradesense.authservice.dto.RegisterRequest;
import mk.tradesense.authservice.jwt.JwtUtils;
import mk.tradesense.authservice.model.UserEntity;
import mk.tradesense.authservice.model.enumerations.Role;
import mk.tradesense.authservice.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

/**
 * Controller for handling authentication and user registration.
 */
@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;

    /**
     * Constructor to initialize dependencies.
     *
     * @param authenticationManager used for authenticating user credentials
     * @param jwtUtils utility class for generating and validating JWT tokens
     * @param passwordEncoder used for encoding user passwords
     * @param userRepository repository for managing user data
     */
    public AuthController(AuthenticationManager authenticationManager, JwtUtils jwtUtils,
                          PasswordEncoder passwordEncoder, UserRepository userRepository) {
        this.authenticationManager = authenticationManager;
        this.jwtUtils = jwtUtils;
        this.passwordEncoder = passwordEncoder;
        this.userRepository = userRepository;
    }

    /**
     * Endpoint for registering a new user.
     *
     * @param request contains user registration details
     * @return response indicating success or failure
     */
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody RegisterRequest request) {
        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("Username already taken");
        }

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("Email already in use");
        }

        UserEntity newUser = new UserEntity(
                request.getUsername(),
                request.getEmail(),
                passwordEncoder.encode(request.getPassword()),
                Role.ROLE_USER
        );

        userRepository.save(newUser);
        return ResponseEntity.status(HttpStatus.CREATED).body("User successfully registered");
    }

    /**
     * Endpoint for logging in a user and generating a JWT token.
     *
     * @param request contains login credentials
     * @return JWT token if credentials are valid, error message otherwise
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );

            SecurityContextHolder.getContext().setAuthentication(auth);
            UserEntity user = (UserEntity) auth.getPrincipal();
            String jwt = jwtUtils.generateTokenFromUsername(user);

            return ResponseEntity.ok(new LoginResponse(jwt, user.getUsername(), Role.ROLE_USER));
        } catch (AuthenticationException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid username or password");
        }
    }

    /**
     * Endpoint to validate the JWT token.
     *
     * @param token the JWT token to validate
     * @return response with the username from the token if valid, error otherwise
     */
    @PostMapping("/validate")
    public ResponseEntity<?> validate(@RequestHeader("Authorization") String token) {
        if (token == null || !token.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Missing or invalid token");
        }

        String jwt = token.substring(7);
        if (!jwtUtils.validateToken(jwt)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Token validation failed");
        }

        String username = jwtUtils.getUsernameFromToken(jwt);
        return ResponseEntity.ok(Map.of("username", username));
    }
}
