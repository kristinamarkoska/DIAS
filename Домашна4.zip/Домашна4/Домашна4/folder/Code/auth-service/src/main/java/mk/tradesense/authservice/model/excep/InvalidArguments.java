package mk.tradesense.authservice.model.exceptions;

/**
 * Custom exception to indicate invalid arguments were provided.
 */
public class InvalidArguments extends RuntimeException {

    /**
     * Default constructor with a predefined message.
     */
    public InvalidArguments() {
        super("Invalid arguments provided");
    }

    /**
     * Constructor allowing a custom error message.
     *
     * @param message the custom error message
     */
    public InvalidArgumentsException(String message) {
