package mk.tradesense.authservice.repository;

import mk.tradesense.authservice.model.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {
    /**
     * Finds a user by their username.
     *
     * @param username the username to search for
     * @return an Optional containing the UserEntity if found
     */
    Optional<UserEntity> findByUsername(String username);

/**
 * Finds a user
