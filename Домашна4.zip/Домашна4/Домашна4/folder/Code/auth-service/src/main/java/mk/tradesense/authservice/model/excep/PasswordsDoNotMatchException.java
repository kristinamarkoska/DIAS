package mk.tradesense.authservice.model.exceptions;

/**
 * Custom exception to indicate that provided passwords do not match.
 */
public class PasswordsDoNotMatchException extends RuntimeException {

    /**
     * Default constructor with a predefined error message.
     */
    public PasswordsDoNotMatchException() {
        super("Passwords do not match");
    }

    /**
     * Constructor allowing a custom error message.
     *
     * @param message the custom error message
     */
    public PasswordsDoNotMatchException(String message) {
        super(message);
    }
}
