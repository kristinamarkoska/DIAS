package mk.tradesense.tradesense.service.impl;

import mk.tradesense.tradesense.repository.StockUserRepository;
import mk.tradesense.tradesense.model_entity.ApplicationUser;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomerDetailsServiceImpl implements UserDetailsService {

    private final StockUserRepository customerRepository;

    public CustomerDetailsServiceImpl(StockUserRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        ApplicationUser customer = customerRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("Customer is not found with this email: " + username));

        return new org.springframework.security.core.userdetails.User(
                customer.getEmail(),
                customer.getPassword(),
                customer.isActive(),
                true,
                true,
                true,
                customer.getAuthorities());
    }
}
