package mk.tradesense.tradesense.data;

import lombok.Data;

@Data
public class UserRegistrationRequest {
    private String userName;
    private String userEmail;
    private String userPassword;
}
