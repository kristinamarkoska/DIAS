package mk.tradesense.tradesense.repository;

import mk.tradesense.tradesense.model_entity.ApplicationUser;
import mk.tradesense.tradesense.model_entity.ApplicationUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface StockUserRepository extends JpaRepository<ApplicationUser, Long> {
    Optional<ApplicationUser> findByUsername(String username);
    Optional<ApplicationUser> findByEmail(String email);
}