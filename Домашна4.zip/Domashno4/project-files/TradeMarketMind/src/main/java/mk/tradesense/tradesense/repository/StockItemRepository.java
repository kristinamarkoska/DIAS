package mk.tradesense.tradesense.repository;

import mk.tradesense.tradesense.model_entity.TradeItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StockItemRepository extends JpaRepository<TradeItem, Long> {

    @Query("SELECT DISTINCT s.stockCode FROM TradeItem s")
    List<String> findDistinctStockCodes();
}