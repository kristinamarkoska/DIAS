package mk.tradesense.tradesense.repository;

import mk.tradesense.tradesense.repository.StockSentimentRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StockSignalRepository extends CrudRepository<StockSentimentRepository, Integer> {
    List<StockSentimentRepository> findSignalsByStockCode(String stockCode);
}
