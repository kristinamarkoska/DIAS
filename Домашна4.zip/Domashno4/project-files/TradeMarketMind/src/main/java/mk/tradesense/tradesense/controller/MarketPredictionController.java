package mk.tradesense.tradesense.controller;

import mk.tradesense.tradesense.model_entity.MarketSentiment;
import mk.tradesense.tradesense.model_entity.TradingSignal;
import mk.tradesense.tradesense.repository.MarketSentimentRepository;
import mk.tradesense.tradesense.repository.TradingSignalRepository;
import org.springframework.web.bind.annotation.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

@RestController
@RequestMapping("/api/market-predictions")
public class MarketPredictionController {

    private final TradingSignalRepository tradingSignalRepository;
    private final MarketSentimentRepository marketSentimentRepository;

    public MarketPredictionController(TradingSignalRepository tradingSignalRepository, MarketSentimentRepository marketSentimentRepository) {
        this.tradingSignalRepository = tradingSignalRepository;
        this.marketSentimentRepository = marketSentimentRepository;
    }

    @PostMapping("/technical-analysis")
    public String performTechnicalAnalysis(@RequestParam String tickerSymbol) {
        // Retrieve the Python path from environment variables
        String pythonExecutablePath = System.getenv("PYTHON_PATH");
        if (pythonExecutablePath == null) {
            throw new IllegalStateException("PYTHON_PATH environment variable is not set");
        }

        try {
            Process process = new ProcessBuilder(pythonExecutablePath, "src/main/java/mk/tradesense/tradesense/scripts/technical_analysis.py", tickerSymbol).start();
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder analysisOutput = new StringBuilder();
            String line;

            while ((line = reader.readLine()) != null) {
                analysisOutput.append(line).append("\n");
            }

            process.waitFor();

            return "Technical analysis result: " + analysisOutput.toString();

        } catch (Exception e) {
            e.printStackTrace();
            return "Error during technical analysis: " + e.getMessage();
        }
    }

    @GetMapping("/trading-signals")
    public List<TradingSignal> fetchTradingSignals(@RequestParam String tickerSymbol) {
        return tradingSignalRepository.findSignalsByStockCode(tickerSymbol);
    }

    @GetMapping("/market-sentiment/{tickerSymbol}")
    public MarketSentiment fetchMarketSentiment(@PathVariable String tickerSymbol) {
        return marketSentimentRepository.findByStockCode(tickerSymbol);
    }
}
