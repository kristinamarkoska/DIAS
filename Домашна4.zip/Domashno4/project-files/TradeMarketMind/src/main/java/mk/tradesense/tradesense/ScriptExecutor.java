package mk.tradesense.tradesense;

import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;

@Component
public class ScriptExecutor {

    private static final Logger logger = LoggerFactory.getLogger(ScriptExecutor.class);

    @PostConstruct
    public void init() {
        try {
            String pythonPath = System.getenv("PYTHON_PATH");
            if (pythonPath == null) {
                throw new IllegalStateException("PYTHON_PATH environment variable is not set");
            }

            ProcessBuilder processBuilder = new ProcessBuilder(pythonPath, "src/main/java/mk/tradesense/tradesense/scripts/scraper_5.py");
            processBuilder.redirectErrorStream(true);
            Process process = processBuilder.start();

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    logger.info(line);
                }
            }

            int exitCode = process.waitFor();
            logger.info("Python script ended with this code: " + exitCode);

        } catch (Exception e) {
            logger.error("Error during script execution: ", e);
        }
    }
}
