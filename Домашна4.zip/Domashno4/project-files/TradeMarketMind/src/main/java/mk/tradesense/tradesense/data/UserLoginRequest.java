package mk.tradesense.tradesense.data;

import lombok.Data;

@Data
public class UserLoginRequest {
    private String userName;
    private String userPassword;
}
