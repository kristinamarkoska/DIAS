import requests
from bs4 import BeautifulSoup
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
import pandas as pd
import psycopg2
from psycopg2.extras import execute_values
import time
import os
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    "dbname": os.getenv("user_name"),
    "user": os.getenv("user_db"),
    "password": os.getenv("Password_db"),
    "host": os.getenv("Host_db"),
    "port": os.getenv("Port_db")
}

BASE_URL = "https://www.mse.mk/mk/stats/symbolhistory/"
issuers_list = []

def contains_digit(text):
    return any(char.isdigit() for char in text)

def retrieve_issuers():
    url = f"{BASE_URL}kmb"
    with requests.Session() as session:
        response = session.get(url)
        soup = BeautifulSoup(response.content, "html.parser")
        options = soup.select("#Code option")
        for option in options:
            issuer = option.text.strip()
            if issuer and not contains_digit(issuer):
                issuers_list.append(issuer)

def get_last_date_in_db(connection):
    with connection.cursor() as cursor:
        cursor.execute("SELECT MAX(date) FROM stock_prices")
        result = cursor.fetchone()
        return result[0] if result[0] else None

def insert_into_db(connection, data):
    insert_sql = """
        INSERT INTO stock_prices (
            stock_code, date, last_price, max_price, min_price, avg_price,
            percent_change, quantity, turnover_best, total_turnover
        ) VALUES %s
    """
    formatted_data = [
        (
            item['Issuer'],
            datetime.strptime(item['Date'], "%d.%m.%Y") if item['Date'] else None,
            float(item['Last_Price'].replace(".", "").replace(",", ".")) if item['Last_Price'] else None,
            float(item['Max_Price'].replace(".", "").replace(",", ".")) if item['Max_Price'] else None,
            float(item['Min_Price'].replace(".", "").replace(",", ".")) if item['Min_Price'] else None,
            float(item['Avg_Price'].replace(".", "").replace(",", ".")) if item['Avg_Price'] else None,
            float(item['Percent_Change'].replace(".", "").replace(",", ".")) if item['Percent_Change'] else 0,
            float(item['Quantity'].replace(".", "").replace(",", ".")) if item['Quantity'] else None,
            float(item['Turnover_Best'].replace(".", "").replace(",", ".")) if item['Turnover_Best'] else None,
            float(item['Total_Turnover'].replace(".", "").replace(",", ".")) if item['Total_Turnover'] else None
        )
        for item in data
    ]
    with connection.cursor() as cursor:
        execute_values(cursor, insert_sql, formatted_data)
    connection.commit()

def fetch_data_for_issuer(issuer, start_date, end_date):
    data = []
    url = f"{BASE_URL}{issuer}"
    with requests.Session() as session:
        payload = {
            "FromDate": start_date.strftime("%d.%m.%Y"),
            "ToDate": end_date.strftime("%d.%m.%Y"),
            "Issuer": issuer
        }
        try:
            response = session.post(url, data=payload)
            soup = BeautifulSoup(response.text, "html.parser")
            table = soup.select_one("#resultsTable tbody")
            if not table:
                return []
            for row in table.find_all("tr"):
                cells = row.find_all("td")
                if len(cells) < 9:
                    continue
                data.append({
                    "Issuer": issuer,
                    "Date": cells[0].text.strip() or None,
                    "Last_Price": cells[1].text.strip() or None,
                    "Max_Price": cells[2].text.strip() or None,
                    "Min_Price": cells[3].text.strip() or None,
                    "Avg_Price": cells[4].text.strip() or None,
                    "Percent_Change": cells[5].text.strip() or None,
                    "Quantity": cells[6].text.strip() or None,
                    "Turnover_Best": cells[7].text.strip() or None,
                    "Total_Turnover": cells[8].text.strip() or None,
                })
        except Exception as error:
            print(f"Error fetching data for {issuer}: {error}")
    return data

def forward_fill_missing_entries(connection):
    with connection.cursor() as cursor:
        cursor.execute("SELECT DISTINCT stock_code FROM stock_prices")
        issuers = [row[0] for row in cursor.fetchall()]

    for issuer in issuers:
        query = """
            SELECT date, last_price, max_price, min_price, avg_price,
                   percent_change, quantity, turnover_best, total_turnover
            FROM stock_prices
            WHERE stock_code = %s
            ORDER BY date
        """
        df = pd.read_sql(query, connection, params=(issuer,))
        full_range = pd.date_range(df['date'].min(), df['date'].max())
        df.set_index('date', inplace=True)
        df = df.reindex(full_range, method='ffill')
        df.index.name = 'date'
        df['stock_code'] = issuer

        existing_dates_query = "SELECT date FROM stock_prices WHERE stock_code = %s"
        with connection.cursor() as cursor:
            cursor.execute(existing_dates_query, (issuer,))
            existing_dates = {row[0] for row in cursor.fetchall()}

        forward_filled = df[~df.index.isin(existing_dates)]

        if not forward_filled.empty:
            insert_sql = """
                INSERT INTO stock_prices (
                    stock_code, date, last_price, max_price, min_price, avg_price,
                    percent_change, quantity, turnover_best, total_turnover
                ) VALUES %s
            """
            formatted_data = [
                (
                    issuer, date, row['last_price'], row['max_price'],
                    row['min_price'], row['avg_price'], row['percent_change'],
                    row['quantity'], row['turnover_best'], row['total_turnover']
                )
                for date, row in forward_filled.iterrows()
            ]
            with connection.cursor() as cursor:
                execute_values(cursor, insert_sql, formatted_data)
            connection.commit()

        print(f"Forward filled {len(forward_filled)} rows for issuer {issuer}")

def main():
    conn = psycopg2.connect(**DATABASE_CONFIG)
    retrieve_issuers()

    last_scraped_date = get_last_date_in_db(conn)
    current_date = datetime.now().date()

    if last_scraped_date == current_date:
        print("Data is up-to-date. No new data needs scraping.")
        conn.close()
        return

    start_date = (last_scraped_date + timedelta(days=1)) if last_scraped_date else (current_date - timedelta(days=365 * 10))
    end_date = current_date

    date_ranges = [
        (start_date + timedelta(days=365 * i),
         min(start_date + timedelta(days=365 * (i + 1)) - timedelta(days=1), end_date))
        for i in range((end_date.year - start_date.year) + 1)
    ]

    start_time = time.time()
    total_added = 0

    with ThreadPoolExecutor(max_workers=50) as executor:
        for issuer in issuers_list:
            results = executor.map(lambda dr: fetch_data_for_issuer(issuer, *dr), date_ranges)
            for result in results:
                if result:
                    insert_into_db(conn, result)
                    total_added += len(result)

    elapsed_time = time.time() - start_time
    print(f"Data scraping took {elapsed_time:.2f} seconds.")
    print(f"Total records added: {total_added}")

    forward_fill_missing_entries(conn)
    conn.close()

if __name__ == "__main__":
    main()
