package mk.tradesense.tradesense.controller;

import mk.tradesense.tradesense.data.UserLoginRequest;
import mk.tradesense.tradesense.data.UserLoginResponse;
import mk.tradesense.tradesense.data.UserRegisterRequest;
import mk.tradesense.tradesense.jason_web.JwtTokenService;
import mk.tradesense.tradesense.model_entity.Account;
import mk.tradesense.tradesense.model_entity.enumerations.UserRole;
import mk.tradesense.tradesense.repository.AccountRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/authentication")
public class AuthenticationController {

    private final AuthenticationManager authenticationManager;
    private final JwtTokenService jwtTokenService;
    private final PasswordEncoder passwordEncoder;
    private final AccountRepository accountRepository;

    public AuthenticationController(AuthenticationManager authenticationManager, JwtTokenService jwtTokenService, PasswordEncoder passwordEncoder, AccountRepository accountRepository) {
        this.authenticationManager = authenticationManager;
        this.jwtTokenService = jwtTokenService;
        this.passwordEncoder = passwordEncoder;
        this.accountRepository = accountRepository;
    }

    // Register a new user
    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@RequestBody UserRegisterRequest userRegisterRequest) {
        // Check if username & email exists
        if (accountRepository.findByUsername(userRegisterRequest.getUsername()).isPresent()) {
            return new ResponseEntity<>("Username is already taken", HttpStatus.BAD_REQUEST);
        }
        if (accountRepository.findByEmail(userRegisterRequest.getEmail()).isPresent()) {
            return new ResponseEntity<>("Email is already in use", HttpStatus.BAD_REQUEST);
        }

        // Create new user
        Account account = new Account(
                userRegisterRequest.getUsername(),
                userRegisterRequest.getEmail(),
                passwordEncoder.encode(userRegisterRequest.getPassword()),
                UserRole.ROLE_USER
        );

        accountRepository.save(account);

        return new ResponseEntity<>("User registered successfully", HttpStatus.CREATED);
    }

    // Login user
    @PostMapping("/signin")
    public ResponseEntity<?> loginUser(@RequestBody UserLoginRequest userLoginRequest) {

        Authentication authentication;
        try {
            authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(userLoginRequest.getUsername(), userLoginRequest.getPassword())
            );
        } catch (AuthenticationException e) {
            Map<String, Object> map = new HashMap<>();
            map.put("message", "Invalid credentials");
            map.put("status", false);
            return new ResponseEntity<Object>(map, HttpStatus.NOT_FOUND);
        }

        SecurityContextHolder.getContext().setAuthentication(authentication);
        Account account = (Account) authentication.getPrincipal();

        String jwtToken = jwtTokenService.generateTokenFromUsername(account);

        UserLoginResponse userLoginResponse = new UserLoginResponse(jwtToken, account.getUsername(), UserRole.ROLE_USER);

        return ResponseEntity.ok(userLoginResponse);
    }

    // Logout user (if needed)
    // @PostMapping("/logout")
    // public ResponseEntity<?> logoutUser(HttpServletRequest request) {
    //
    // }
}
