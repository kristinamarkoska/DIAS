package mk.tradesense.tradesense.controller;

import mk.tradesense.tradesense.model_entity.StockEntry;
import mk.tradesense.tradesense.repository.StockEntryRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/stock-entries")
public class StockEntryController {

    private final StockEntryRepository stockEntryRepository;

    public StockEntryController(StockEntryRepository stockEntryRepository) {
        this.stockEntryRepository = stockEntryRepository;
    }

    @PostMapping
    public ResponseEntity<StockEntry> addStockEntry(@RequestBody StockEntry stockEntry) {
        StockEntry savedStockEntry = stockEntryRepository.save(stockEntry);
        return ResponseEntity.ok(savedStockEntry);
    }

    @GetMapping
    public ResponseEntity<List<StockEntry>> getAllStockEntries() {
        List<StockEntry> stockEntries = stockEntryRepository.findAll();
        return ResponseEntity.ok(stockEntries);
    }

    @GetMapping("/{id}")
    public ResponseEntity<StockEntry> getStockEntryById(@PathVariable Long id) {
        return stockEntryRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> removeStockEntry(@PathVariable Long id) {
        if (stockEntryRepository.existsById(id)) {
            stockEntryRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/codes")
    public ResponseEntity<List<String>> getDistinctStockCodes() {
        List<String> stockCodes = stockEntryRepository.findDistinctStockCodes();
        return ResponseEntity.ok(stockCodes);
    }
}
