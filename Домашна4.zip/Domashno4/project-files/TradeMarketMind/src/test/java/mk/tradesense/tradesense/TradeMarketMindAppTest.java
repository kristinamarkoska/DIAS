package mk.tradesense.tradesense;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TradeMarketMindAppTest {

	@Test
	void contextLoads() {
	}

}
